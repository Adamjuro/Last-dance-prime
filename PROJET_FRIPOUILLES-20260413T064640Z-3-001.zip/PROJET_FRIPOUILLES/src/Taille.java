import java.util.ArrayList;
import java.util.List;

/**
 * Repr�sente une taille pour un article.
 * Contient un identifiant et un libell�.
 * Permet �galement de g�rer une liste statique de tailles.
 */
public class Taille {

    // =========================
    // Attributs
    // =========================
    private int idTaille;
    private String libelle;

    // =========================
    // Constructeurs
    // =========================

    /** Constructeur par d�faut */
    public Taille() {
    }

    /**
     * Constructeur complet
     * @param unIdTaille Identifiant de la taille
     * @param unLibelle Libell� de la taille
     */
    public Taille(int unIdTaille, String unLibelle) {
        this.idTaille = unIdTaille;
        this.libelle = unLibelle;
    }

    // =========================
    // Getters et Setters
    // =========================
    public int getIdTaille() {
        return idTaille;
    }

    public void setIdTaille(int unIdTaille) {
        this.idTaille = unIdTaille;
    }

    public String getLibelle() {
        return libelle;
    }

    public void setLibelle(String unLibelle) {
        this.libelle = unLibelle;
    }

    // =========================
    // Gestion de la liste statique de tailles
    // =========================
    private static List<Taille> lesTailles = new ArrayList<>();

    public static void setLesTailles(List<Taille> lesTailles) {
        Taille.lesTailles = lesTailles;
    }

    public static List<Taille> getLesTailles() {
        return Taille.lesTailles;
    }

    /**
     * Retourne la taille correspondant � l'identifiant donn�
     * @param idTaille Identifiant recherch�
     * @return Objet Taille ou null si non trouv�
     */
    public static Taille getTailleById(int idTaille) {
        for (Taille taille : lesTailles) {
            if (taille.getIdTaille() == idTaille) {
                return taille;
            }
        }
        return null;
    }

    // =========================
    // M�thodes
    // =========================

    @Override
    public String toString() {
        return this.libelle;
    }
}
