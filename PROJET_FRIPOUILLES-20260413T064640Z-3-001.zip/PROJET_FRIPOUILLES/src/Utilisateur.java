/**
 * Classe abstraite repr�sentant un utilisateur de l'application.
 * Elle contient les informations communes � tous les utilisateurs : 
 * identifiant, login et r�le.
 */
public abstract class Utilisateur {

    // =========================
    // Attributs
    // =========================
    protected int idUser;   // Identifiant unique de l'utilisateur
    protected String login; // Nom de connexion
    protected String role;  // R�le de l'utilisateur (Benevole, Secretaire, Maire, etc.)

    // =========================
    // Constructeur
    // =========================
    /**
     * Constructeur complet
     * @param idUser Identifiant unique de l'utilisateur
     * @param login Nom de connexion
     * @param role R�le de l'utilisateur
     */
    public Utilisateur(int idUser, String login, String role) {
        this.idUser = idUser;
        this.login = login;
        this.role = role;
    }

    // =========================
    // Getters
    // =========================
    /**
     * Retourne l'identifiant de l'utilisateur
     * @return idUser
     */
    public int getIdUser() {
        return idUser;
    }

    /**
     * Retourne le login de l'utilisateur
     * @return login
     */
    public String getLogin() {
        return login;
    }

    /**
     * Retourne le r�le de l'utilisateur
     * @return role
     */
    public String getRole() {
        return role;
    }
}
