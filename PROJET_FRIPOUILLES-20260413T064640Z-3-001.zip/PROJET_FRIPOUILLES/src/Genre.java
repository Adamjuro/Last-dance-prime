/**
 * Classe repr�sentant un Genre d'article (ex : Homme, Femme, Enfant).
 * Chaque genre poss�de un identifiant unique et un libell�.
 */
public class Genre {

    // =========================
    // Attributs
    // =========================
    private int idGenre;      // Identifiant unique du genre
    private String libelle;   // Libell� du genre (ex : Homme, Femme)

    // =========================
    // Constructeurs
    // =========================

    /**
     * Constructeur par d�faut.
     */
    public Genre() {
    }

    /**
     * Constructeur complet.
     *
     * @param unIdGenre Identifiant du genre
     * @param unLibelle Libell� du genre
     */
    public Genre(int unIdGenre, String unLibelle) {
        this.idGenre = unIdGenre;
        this.libelle = unLibelle;
    }

    // =========================
    // Getters et Setters
    // =========================

    /**
     * Retourne l'identifiant du genre.
     *
     * @return identifiant du genre
     */
    public int getIdGenre() {
        return idGenre;
    }

    /**
     * D�finit l'identifiant du genre.
     *
     * @param unIdGenre identifiant � d�finir
     */
    public void setIdGenre(int unIdGenre) {
        this.idGenre = unIdGenre;
    }

    /**
     * Retourne le libell� du genre.
     *
     * @return libell�
     */
    public String getLibelle() {
        return libelle;
    }

    /**
     * D�finit le libell� du genre.
     *
     * @param unLibelle libell� � d�finir
     */
    public void setLibelle(String unLibelle) {
        this.libelle = unLibelle;
    }

    // =========================
    // M�thodes utilitaires
    // =========================

    /**
     * Retourne le libell� du genre pour l'affichage.
     *
     * @return libell�
     */
    @Override
    public String toString() {
        return this.libelle;
    }
}
