/**
 * Classe repr�sentant l'�tat d'un article.
 * Par exemple : Neuf, Comme Neuf, Usag�, etc.
 */
public class Etat {

    // ========================
    // Attributs
    // ========================
    private int idEtat;    // Identifiant unique de l'�tat
    private String libelle; // Nom de l'�tat

    // ========================
    // Constructeurs
    // ========================

    /**
     * Constructeur par d�faut.
     */
    public Etat() {
    }

    /**
     * Constructeur avec initialisation des attributs.
     *
     * @param unIdEtat Identifiant unique de l'�tat
     * @param unLibelle Nom de l'�tat
     */
    public Etat(int unIdEtat, String unLibelle) {
        this.idEtat = unIdEtat;
        this.libelle = unLibelle;
    }

    // ========================
    // Getters et Setters
    // ========================

    /**
     * @return L'identifiant unique de l'�tat
     */
    public int getIdEtat() {
        return idEtat;
    }

    /**
     * D�finit l'identifiant unique de l'�tat
     *
     * @param unIdEtat Nouvel identifiant
     */
    public void setIdEtat(int unIdEtat) {
        this.idEtat = unIdEtat;
    }

    /**
     * @return Le libell� (nom) de l'�tat
     */
    public String getLibelle() {
        return libelle;
    }

    /**
     * D�finit le libell� (nom) de l'�tat
     *
     * @param unLibelle Nouveau libell�
     */
    public void setLibelle(String unLibelle) {
        this.libelle = unLibelle;
    }

    // ========================
    // M�thodes
    // ========================

    /**
     * Permet d'afficher directement le libell� dans les JComboBox ou logs
     *
     * @return Le libell� de l'�tat
     */
    @Override
    public String toString() {
        return this.libelle;
    }
}
