/**
 * Classe repr�sentant un utilisateur de type B�n�vole.
 * H�rite de la classe Utilisateur.
 * 
 * Les b�n�voles peuvent enregistrer les articles � vendre
 * et consulter le catalogue des articles.
 */
public class Benevole extends Utilisateur {

    /**
     * Constructeur pour cr�er un b�n�vole avec son identifiant et login.
     * Le r�le est automatiquement d�fini � "BENEVOLE".
     *
     * @param idUser Identifiant unique de l'utilisateur
     * @param login  Nom de connexion de l'utilisateur
     */
    public Benevole(int idUser, String login) {
        super(idUser, login, "BENEVOLE");
    }
}
