/**
 * Classe repr�sentant une couleur d'article.
 * Chaque article peut avoir une couleur (ex : Rouge, Bleu, Vert, etc.).
 */
public class Couleur {

    // ========================
    // Attributs
    // ========================
    private int idCouleur;  // Identifiant unique de la couleur
    private String libelle; // Nom de la couleur

    // ========================
    // Constructeurs
    // ========================

    /**
     * Constructeur par d�faut.
     */
    public Couleur() {
    }

    /**
     * Constructeur avec initialisation des attributs.
     *
     * @param unIdCouleur Identifiant unique de la couleur
     * @param unLibelle   Nom de la couleur
     */
    public Couleur(int unIdCouleur, String unLibelle) {
        this.idCouleur = unIdCouleur;
        this.libelle = unLibelle;
    }

    // ========================
    // Getters et Setters
    // ========================

    /**
     * @return L'identifiant unique de la couleur
     */
    public int getIdCouleur() {
        return idCouleur;
    }

    /**
     * D�finit l'identifiant unique de la couleur
     *
     * @param unIdCouleur Nouvel identifiant
     */
    public void setIdCouleur(int unIdCouleur) {
        this.idCouleur = unIdCouleur;
    }

    /**
     * @return Le libell� (nom) de la couleur
     */
    public String getLibelle() {
        return libelle;
    }

    /**
     * D�finit le libell� (nom) de la couleur
     *
     * @param unLibelle Nouveau libell�
     */
    public void setLibelle(String unLibelle) {
        this.libelle = unLibelle;
    }

    // ========================
    // M�thodes
    // ========================

    /**
     * Permet d'afficher directement le libell� dans les JComboBox ou logs
     *
     * @return Le libell� de la couleur
     */
    @Override
    public String toString() {
        return this.libelle;
    }
}
