/**
 * Repr�sente un utilisateur de type Secr�taire.
 * H�rite de la classe Utilisateur.
 */
public class Secretaire extends Utilisateur {

    /**
     * Constructeur.
     * @param idUser Identifiant de l'utilisateur
     * @param login Login de l'utilisateur
     */
    public Secretaire(int idUser, String login) {
        super(idUser, login, "SECRETAIRE");
    }
}
