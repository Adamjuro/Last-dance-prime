/**
 * Classe repr�sentant un utilisateur de type Maire.
 * H�rite de la classe Utilisateur.
 */
public class Maire extends Utilisateur {

    /**
     * Constructeur.
     * @param idUser Identifiant de l'utilisateur
     * @param login Login de l'utilisateur
     */
    public Maire(int idUser, String login) {
        // On fixe le r�le � "MAIRE"
        super(idUser, login, "MAIRE");
    }
}
