/**
 * Classe repr�sentant une cat�gorie d'article.
 * Chaque article appartient � une cat�gorie (ex : V�tements, Chaussures, Accessoires, etc.).
 */
public class Categorie {

    // ========================
    // Attributs
    // ========================
    private int idCategorie;  // Identifiant unique de la cat�gorie
    private String libelle;   // Nom de la cat�gorie

    // ========================
    // Constructeurs
    // ========================

    /**
     * Constructeur par d�faut.
     */
    public Categorie() {
    }

    /**
     * Constructeur avec initialisation des attributs.
     *
     * @param unIdCategorie Identifiant unique de la cat�gorie
     * @param unLibelle     Nom de la cat�gorie
     */
    public Categorie(int unIdCategorie, String unLibelle) {
        this.idCategorie = unIdCategorie;
        this.libelle = unLibelle;
    }

    // ========================
    // Getters et Setters
    // ========================

    /**
     * @return L'identifiant unique de la cat�gorie
     */
    public int getIdCategorie() {
        return idCategorie;
    }

    /**
     * D�finit l'identifiant unique de la cat�gorie
     *
     * @param unIdCategorie Nouvel identifiant
     */
    public void setIdCategorie(int unIdCategorie) {
        this.idCategorie = unIdCategorie;
    }

    /**
     * @return Le libell� (nom) de la cat�gorie
     */
    public String getLibelle() {
        return libelle;
    }

    /**
     * D�finit le libell� (nom) de la cat�gorie
     *
     * @param unLibelle Nouveau libell�
     */
    public void setLibelle(String unLibelle) {
        this.libelle = unLibelle;
    }

    // ========================
    // M�thodes
    // ========================

    /**
     * Permet d'afficher directement le libell� dans les JComboBox ou logs
     *
     * @return Le libell� de la cat�gorie
     */
    @Override
    public String toString() {
        return this.libelle;
    }
}
