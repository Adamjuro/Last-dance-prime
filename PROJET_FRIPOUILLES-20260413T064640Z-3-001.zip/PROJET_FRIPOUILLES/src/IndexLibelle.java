/**
 * Classe repr�sentant un couple index/libell�.
 * Utile pour les JComboBox ou autres listes d�roulantes
 * o� l'on souhaite stocker � la fois un identifiant et un texte affich�.
 */
public class IndexLibelle {

    // =========================
    // Attributs
    // =========================
    private int index;       // Identifiant ou position associ� au libell�
    private String libelle;  // Texte affich� dans la liste

    // =========================
    // Constructeur
    // =========================

    /**
     * Constructeur complet.
     *
     * @param index  L'index ou identifiant associ�
     * @param libelle Le libell� affich�
     */
    public IndexLibelle(int index, String libelle) {
        this.index = index;
        this.libelle = libelle;
    }

    // =========================
    // Getters
    // =========================

    /**
     * Retourne l'index associ� � ce libell�.
     *
     * @return index
     */
    public int getIndex() {
        return this.index;
    }

    /**
     * Retourne le libell� associ� � cet index.
     *
     * @return libell�
     */
    public String getLibelle() {
        return this.libelle;
    }

    // =========================
    // M�thodes utilitaires
    // =========================

    /**
     * Retourne le libell� pour l'affichage.
     * Cette m�thode est appel�e automatiquement par les JComboBox.
     *
     * @return libell�
     */
    @Override
    public String toString() {
        return this.libelle;
    }
}
